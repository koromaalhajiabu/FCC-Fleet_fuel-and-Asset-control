# FCC Fleet, Fuel & Asset Control — v0.3

An offline-first system for Freetown City Council fleet, fuel, maintenance, asset and stores control.

## What it does

- **Dashboard**: fleet condition, fuel totals, open maintenance, low stock, and control alerts (expired or soon-expiring insurance and licences, open jobs, service due dates, low stock, pending vehicle requests).
- **Registers**: Fleet, Fuel Control, Maintenance, Asset Register, Stores & Inventory, Vehicle Requests, Suppliers, Staff Directory.
- Add, edit, delete, search and filter by status or condition.
- Validation: required fields, no negative numbers, unique registration/asset tag/stock code/staff ID/receipt reference.
- Export any register to CSV (opens in Excel).
- Full JSON backup and restore.
- Print or save as PDF.
- Works offline once loaded; installable as an app on phones and computers.

## Running it

**Option 1 — Open directly:** double-click `index.html`. Everything works, but the offline cache and "install" feature need Option 2.

**Option 2 — Host it (recommended):** upload the whole folder to any static host (for example Netlify, Cloudflare Pages, GitHub Pages, or a council web server). Open the address in a browser, then use "Install app" or "Add to Home Screen".

**Option 3 — Local test server:**

```
cd fcc-fleet-app
python3 -m http.server 8080
```

Then open http://localhost:8080.

## Sign-in

The local demo login is **admin / 1234**. It is a placeholder for testing only. Before any real use, replace it with proper staff accounts (see the production checklist in the app).

## Where data lives

Records are stored in the browser's local storage on that device. Clearing browser data or switching devices will lose records unless you export a backup. Use **Export backup** regularly.

Sample records are marked "Demo" and are fictional; delete them or restore an empty backup when you start real data entry.

## Files

| File | Purpose |
|---|---|
| `index.html` | Page structure |
| `styles.css` | Layout and styling |
| `app.js` | All application logic |
| `sw.js` | Offline caching |
| `manifest.webmanifest` | App install settings |
| `icon.svg` | App icon |

## Not yet included

- Multi-device sync and a shared database (needs a hosted database with role-based access rules).
- Real staff authentication and audit logs.
- PNG app icons for older devices (the SVG icon works on current browsers).

These are needed before live operational use. Designed by Alhaji Abu Koroma · Pilot v0.3
